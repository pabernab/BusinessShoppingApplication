package Controller;

public class CustomerMessage implements Message {
}