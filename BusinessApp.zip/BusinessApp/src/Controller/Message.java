package Controller;

import java.io.Serializable;

/**
 * Represents message (event) sent from View to Model
 */
public interface Message extends Serializable {

}

