package Controller;

public class PayMessage implements Message {
}
