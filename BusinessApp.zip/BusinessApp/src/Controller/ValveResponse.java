package Controller;

public enum ValveResponse {
    MISS,
    CUSTOMER,
    ADD_ITEM,
    PAYMENT,
    FINISH,
    EXECUTED;
}

