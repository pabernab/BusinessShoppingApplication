package Controller;

public class AddItemMessage implements Message {
}
