package Controller;

public class StartMessage implements Message{
}
