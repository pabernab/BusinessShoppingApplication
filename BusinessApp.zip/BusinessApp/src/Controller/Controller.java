package Controller;

import View.Main;
import Model.*;
import View.*;
import List.*;

import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/***
 * A controller class to relay information between the model and view classes.
 */
public class Controller {

    public BlockingQueue<Message> queue;
    private Main view; // Direct reference to view



    private CustomerList customerList = new CustomerList();
    public List<Valve> valves = new LinkedList<Valve>();

    /***
     *
     * @param view Direct reference to the view class.
     * @param queue A queue that is accessed by the valve interface to determine the appropriate action in response to user input.
     */
    public Controller(Main view, BlockingQueue<Message> queue) {
        this.view = view;
        this.queue = queue;
        valves.add(new DoCustomerValve());
//        valves.add(new DoAddItemValve());

    }

    /***
     * The main loop for the program.
     */
    public void mainLoop() {
        ValveResponse response = ValveResponse.CUSTOMER;
        Message message = null;
        while (response != ValveResponse.FINISH) {
            try {

                message = queue.take(); // <--- take next message from the queue
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // Look for a Valve that can process a message
            for (Valve valve : valves) {
                response = valve.execute(message);
                // if successfully processed, leave the loop
                if (response != ValveResponse.MISS) {
                    break;
                }
            }
        }
    }


    private interface Valve {
        /**
         * Performs certain action in response to message
         */
        public ValveResponse execute(Message message);
    }

    /***
     * Valve implementation that executes a customer related action.
     */
    public class DoCustomerValve implements Valve {
        @Override
        public ValveResponse execute(Message message) {
            if (message.getClass() != CustomerMessage.class) {
                return ValveResponse.MISS;
            }

                view.displayCustomer();
                view.frmMenu.setVisible(true);
                valves.add(new DoAddItemValve());
                return ValveResponse.CUSTOMER;

        }
    }


    /***
     * Valve implementation that executes a item related action.
     */
    public class DoAddItemValve implements Valve {
        @Override
        public ValveResponse execute(Message message) {
            if (message.getClass() != AddItemMessage.class) {
                return ValveResponse.MISS;
            }

                JList jl = view.displayMenu();

                view.frmMenu.add(jl);
                JPanel jp = view.orderSummary();
                view.frmMenu.getContentPane().add(jp);
                view.frmMenu.setVisible(true);
                return ValveResponse.ADD_ITEM;

        }
    }







}





