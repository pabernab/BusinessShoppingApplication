package List;

import java.util.ArrayList;
import java.util.List;

import Model.Customer;

public class CustomerList {
	List<Customer> customers = new ArrayList();
	Customer customer1 = new Customer(68965,"Original Joes","901 S First Street", 4384.00,8000.00);
	Customer customer2 = new Customer(68966,"Patty's Inn","116 Capitol Street", 3568.00, 6000.00);
	Customer customer3 = new Customer(70098,"O'Sullivan Bar","980 Fremont Blvd", 2870.00, 5000.00);
	Customer customer4 = new Customer(70125,"4th Street Bowl","181 S 4th Street", 1980.00, 4500.00);
	Customer customer5 = new Customer(71256,"A Bellagio","658 Campbell Ave ", 3450.00, 4500.00);
	Customer customer6 = new Customer(89685,"Aldo's Ristorante","589 Los Gatos Blvd", 5864.00, 9000.00);
	Customer customer7 = new Customer(88056,"Andale Mexican Restaurant","2285 Santa Cruz Ave", 3658.00, 4500.00);
	Customer customer8 = new Customer(69852,"Boiler Maker","587 Campbell Ave", 1987.00, 4000.00);
	Customer customer9 = new Customer(58745,"Dry Creek Grill","5478 Hamilton Ave", 6547.00, 9000.00);
	Customer customer10 = new Customer(55897,"Los Gatos Golf Course","6941 Winchester Blvd", 5418.00, 8000.00);
	public List addCustomer() {
		customers.add(customer1);
		customers.add(customer2);
		customers.add(customer3);
		customers.add(customer4);
		customers.add(customer5);
		customers.add(customer6);
		customers.add(customer7);
		customers.add(customer8);
		customers.add(customer9);
		customers.add(customer10);

		return customers;
	}
}