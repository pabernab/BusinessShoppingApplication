package Model;

public interface LineItem {


    /***
     *
     * @return returns the associated name.
     */
    public String getName();


    /***
     *
     * @return returns the associated ID.
     */
    public int getID();

    /***
     *
     * @return returns the price.
     */
    public double getPrice();

    /***
     *
     * @return returns a string representation of the object.
     */
    public String toString();

}