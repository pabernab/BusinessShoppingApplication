package Model;

/***
 * Model class representation of an item available for purchase.
 */
public class Item implements LineItem{
    private String name;
    private int ID;
    private double price;

    /***
     *
     * @param name the name of the item.
     * @param ID the id of the item.
     * @param price the price of the item.
     */
    public Item(String name, int ID, double price) {
        this.name = name;
        this.ID = ID;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public int getID() {
        return ID;
    }

    public double getPrice() {
        return price;
    }
    
    public String toString() {
    	return name;
    }
    
}
