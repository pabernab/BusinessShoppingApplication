package Model;

/***
 * A model class representation of a discounted item or bundle.
 */
public class Discount implements LineItem {
    protected String name;
    protected int ID;
    protected double price;

    /***
     *
     * @param i the item to be discounted.
     * @param discount the percentage of discount that is applied to the item.
     */
    public Discount(Item i, double discount) {
        name = i.getName() + " (Discounted)";
        ID = i.getID() + 10000;
        price = i.getPrice() * (1 - discount);

    }

    /***
     *
     * @param b the bundle to be discounted.
     * @param discount the percentage of discount that is applied to the item.
     */
    public Discount(Bundle b, double discount) {
        name = b.getName() + " (Discounted)";
        ID = b.getID() + 10000;
        price = b.getPrice() * (1 - discount);
    }



    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getID() {
        return ID;
    }

    @Override
    public double getPrice() {
        return price;
    }
    
    public String toString() {
    	return name;
    }


}
