package Model;

/***
 * A model class representing a customer and their relevant information.
 */
public class Customer {
    public String name;
    public int ID;
    public String address;
    public double balance;
    public double credit_limit;
    public Order newOrder;

    /***
     *
     * @param xID the id of the Customer
     * @param xName the name of the customer.
     * @param xAddress the address of the customer
     * @param xBalance the amount of money the customer has to use for purchases
     * @param xCredit_limit the maximum amount of money the customer can have for purchases
     */
    public Customer(int xID, String xName, String xAddress, double xBalance, double xCredit_limit) {
        ID = xID;
        name = xName;
        address = xAddress;
        balance = xBalance;
        credit_limit = xCredit_limit;
    }

    public Customer() {
	}
    
	public String getName() {
		return name;
	}

    /***
     *
     * @param newBalance the amount of money to be added to the current balance
     */
	public void UpdateBalance(double newBalance) {
        balance += newBalance;
    }

    public double getBalance() {
        return balance;
    }

    /***
     *
     * @return returns the current credit balance of the customer.
     */
    public String showBalance() {
    	StringBuilder str = new StringBuilder();
    	
    	str.append(balance);
    	return str.toString();
    }

    public void addOrder(Order O) {
    newOrder = O;
    }

    public Order getNewOrder()
    {return newOrder;}
    
    
	public String toString() {
		StringBuilder str = new StringBuilder();
		
		str.append("ID: " +ID + "\n") ;
		str.append("NAME: " +name + "\n");
		str.append(address + "\n");
		str.append("BALANCE: $" + balance + "\n");
		str.append("CREDIT LIMIT: $" +credit_limit + "\n");
		str.append("\n");
		
		return str.toString();
	}
}
