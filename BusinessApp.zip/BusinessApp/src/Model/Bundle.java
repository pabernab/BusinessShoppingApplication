package Model;

import java.util.ArrayList;

/***
 * A representation of a bundle of items available for purchase.
 */

public class Bundle implements LineItem {
    private String name;
    private int ID;
    private double price;
    public ArrayList<Item> items = new ArrayList<>();


    /***
     *
     * @param name the name of the item bundle
     * @param ID the ID of the item bundle
     * @param price the price of the bundle
     */
    public Bundle(String name, int ID, double price) {
        this.name = name;
        this.ID = ID;
        this.price = price;
    }

    /***
     *
     * @param a the item to be added to the bundle list.
     */
    public void addItem(Item a){
        items.add(a);
        name+=a.getName()+ ", ";
        price += a.getPrice();
    }

    public String getName() {
        return name;
    }


    public int getID() {
        return ID;
    }


    public double getPrice() {
        return price;
    }

  
    public String toString() {
    	return name;
    }

}
