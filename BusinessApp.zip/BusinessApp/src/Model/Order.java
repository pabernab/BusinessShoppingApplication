package Model;

import java.util.ArrayList;

/***
 * A model class representation for an order of items.
 */
public class Order {
	
	ArrayList<LineItem> itemList;
	public final double tax = 0.09;
	double totalPrice;
	double priceAfterTax;
	
	public Order () {
		this.itemList = new ArrayList<LineItem>();
	}

	/***
	 * Adds a item to the list.
	 * @param lineItem An object that implements LineItem to be added to the list of items.
	 * @return returns true if an item is successfully added, false if otherwise.
	 */
	public boolean addItem ( LineItem lineItem) {
		if (lineItem == null)
			return false;
		else {
			itemList.add(lineItem);
			return true;
		}	
	}


	public boolean addItem ( Bundle b) {
		if (b == null)
			return false;
		else {
			itemList.add(b);
			return true;
		}	
	}

	public boolean addItem ( Discount d) {
		if (d == null)
			return false;
		else {
			itemList.add(d);
			return true;
		}	
	}

	/***
	 *  Iterates through the item list and adds the respective prices for those items together.
	 * @return returns the total price of all items in the list added together.
	 */
	public double getPrice () {
		totalPrice = 0;
		for ( LineItem i : itemList) {
			totalPrice += i.getPrice();

		}
		return totalPrice;
	}
	public double getTotalPrice() {
		return this.totalPrice;
	}
	public double calculateTotal() {
		priceAfterTax = totalPrice * ( 1 + tax);
		return priceAfterTax;

	}

	public int getOrder(int index) {
		return itemList.get(index).getID();
	}
	public ArrayList<LineItem> getOrderList() {
		return itemList;
	}

	public String toString() {
		StringBuilder str = new StringBuilder();
		for ( int i = 0 ; i < itemList.size(); i ++) {
			str.append(itemList.get(i).getName()) ;
			str.append(" - "+ itemList.get(i).getID()+ " -");
			str.append(" $"+ itemList.get(i).getPrice());
			str.append("\n");
		}
		return str.toString();
		
	}
	
	public String toStringforPayFrame() {
		StringBuilder str = new StringBuilder();
		str.append(getPrice());
		return str.toString();
	}

}