package View;

import Controller.Controller;
import Controller.CustomerMessage;
import Controller.Message;
import Controller.AddItemMessage;
import Controller.PayMessage;


import Controller.ValveResponse;
import Model.*;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import List.CustomerList;
import List.MenuList;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/***
 * A class to display the Customer, Order, and payment screen.
 */
public class Main extends JFrame{
    private BlockingQueue<Message> queue;
	private static final long serialVersionUID = 1L;
    MenuList menu = new MenuList();
    CustomerList customerList = new CustomerList();
    static Order order = new Order();
    CustomerView customerView;
    public Controller action;
	public JFrame frmMenu = new JFrame();
    JTextArea textArea = new JTextArea();
    JButton addButton;
    JButton payButton;

    Controller controller;
    public JPanel orderPanel;
    public JPanel customerPanel;
    public JList list;

    List itemList = null;

    public static int selectedIndex = 0;
    static double price = 0.0;

    /***
     *
     * @param queue A queue of messages for the Valve to execute a appropriate action.
     *
     */
    public Main(BlockingQueue<Message> queue) throws InterruptedException {
        this.queue = queue;
        initialize();
    }
    public void initialize() throws InterruptedException {
        frmMenu.setTitle("Menu");

         this.queue.put(new CustomerMessage());
         this.queue.put(new AddItemMessage());

        frmMenu.setBounds(100, 100, 900, 600);
        frmMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmMenu.getContentPane().setLayout(null);

    }

    /***
     * A method to display the customer, and add to the frame.
     */
    public void displayCustomer() {
        customerPanel = new JPanel();
        final List customers = customerList.addCustomer();
        customerView = new CustomerView(customers);

        frmMenu.add(customerPanel);

        customerPanel.setBackground(Color.WHITE);
        customerPanel.setBounds(10, 20, 535, 184);
        customerPanel.setLayout(null);

        customerView.setBounds(10, 5, 515, 169);
        customerView.setLayout(null);


        customerPanel.add(customerView);
        frmMenu.getContentPane().add(customerPanel);
        customerPanel.validate();
        frmMenu.add(customerPanel);


    }

    /***
     * A method to display the menu.
     * @return the itemlist to be displayed on the menu.
     */
    public JList displayMenu(){
        itemList = menu.addMenuList();
        DefaultListModel listModel = new DefaultListModel();
        listModel.addAll(itemList);
        list = new JList(listModel);
        list.setBounds(10, 214, 535, 302);


        return list;
    }

    /***
     * A method to add to display the order summary and add to the frame.
     * @return
     */
    public JPanel orderSummary(){
        orderPanel = new JPanel();
        orderPanel.setBackground(Color.WHITE);
        orderPanel.setBounds(555, 21, 324, 495);
        orderPanel.setLayout(null);

        JLabel summaryLabel = new JLabel("Order Summary");
        summaryLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
        summaryLabel.setBounds(10, 10, 121, 30);
        summaryLabel.setBackground(Color.BLACK);
        orderPanel.add(summaryLabel);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 50, 304, 322);
        orderPanel.add(scrollPane);
        scrollPane.setViewportView(textArea);
        textArea.setEditable(false);
        textArea.setFont(new Font("Tahoma", Font.PLAIN, 14));

        addButton();
        payButton();

        return orderPanel;
    }

    /***
     *
     * A method to add a button to the frame that allows the user to add an item to their order.
     */
    public void addButton(){
        addButton = new JButton("ADD");
        addButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        addButton.setBounds(10, 382, 138, 39);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addItemFunction();
            }
        });
        orderPanel.add(addButton);
    }

    /***
     * A method to add a button to the frame that allows the user to pay for their order.
     */
    public void payButton(){
        payButton = new JButton("PAY");
        payButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                payButtonFunction();
            }
        });
        payButton.setFont(new Font("Tahoma", Font.BOLD, 16));
        payButton.setBounds(176, 382, 138, 39);
        orderPanel.add(payButton);
    }

    /***
     * A method to call the payframe class in order to process a payment from a customer.
     */
    public void payButtonFunction(){
        price = order.getPrice();
        System.out.println(price);
        Customer c = customerView.selectedCustomer ;
        c.addOrder(order);
        PayFrame payframe = new PayFrame(c);
        frmMenu.dispose();
        payframe.setVisible(true);
        payframe.setBounds(100, 100, 621, 522);
        payframe.setSize( 621,522 );
    }

    /***
     * A method to add an item to the order.
     */
    public void addItemFunction(){
            selectedIndex = list.getSelectedIndex();
            LineItem selectedItem = (LineItem)  itemList.get(selectedIndex);
            System.out.println(selectedItem.getName());
            order.addItem(selectedItem);
            textArea.setText(order.toString());
            textArea.revalidate();
    }


}
