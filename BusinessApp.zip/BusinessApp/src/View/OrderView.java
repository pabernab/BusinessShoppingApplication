package View;

import Model.LineItem;
import Model.Order;

import javax.swing.*;
import java.util.ArrayList;

/***
 * A view class displaying the information associated with a customer's order.
 */

public class OrderView extends JPanel {
    JTextArea orderInfo = new JTextArea();
    Order order;
    JTextArea orderTotal = new JTextArea();

    /***
     *
     * @param order The order to be displayed.
     */
    public OrderView(Order order)
    {
        this.order = order;
        add(orderInfo);
        add(orderTotal);

        orderInfo.setText(order.toString());
        String total = String.valueOf(order.getPrice());
        orderTotal.setText(total);

    }
}
