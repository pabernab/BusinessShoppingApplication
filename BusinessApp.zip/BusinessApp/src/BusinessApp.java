
import Controller.*;

import List.CustomerList;
import List.MenuList;
import Model.*;
import View.*;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

    public class BusinessApp {
        private static BlockingQueue<Message> queue = new ArrayBlockingQueue<Message>(5);
        private static Main view;
        private static CustomerList customerModel;
        private static MenuList itemMenu;

        public static void main(String[] args) throws InterruptedException {
            view = new Main(queue);
            Controller controller = new Controller(view, queue);
            controller.mainLoop();

            view.dispose();
            queue.clear();
        }


}

